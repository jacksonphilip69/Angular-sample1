export class Header {
	id: number;
	name: string;
	tagline: string;
	title: string;
	description: string;
	image: string;
	buttontext: string;
	buttonlink: string;
}
