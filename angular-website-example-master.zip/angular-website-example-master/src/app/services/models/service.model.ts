export class Service {
	id: number;
	name: string;
	tagline: string;
	title: string;
	description: string;
}
