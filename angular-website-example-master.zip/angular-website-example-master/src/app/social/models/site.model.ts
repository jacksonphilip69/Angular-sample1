export class Site {
	id: number;
	link: string;
	title: string;
	target: string;
	username: string;
	icon: string;
}
