export class Feature {
	id: number;
	icon: string;
	title: string;
	description: string;
}
