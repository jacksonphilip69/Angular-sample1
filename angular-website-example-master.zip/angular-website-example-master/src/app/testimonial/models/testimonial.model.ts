export class Testimonial {
	id: number;
	name: string;
	tagline: string;
	title: string;
	description: string;
}
