export class Footer {
	id: number;
	name: string;
	tagline: string;
	developer: string;
	developerlink: string;
}
