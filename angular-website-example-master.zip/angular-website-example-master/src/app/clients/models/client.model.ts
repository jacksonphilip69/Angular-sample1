export class Client {
	id: number;
	name: string;
	tagline: string;
	title: string;
	description: string;
}
