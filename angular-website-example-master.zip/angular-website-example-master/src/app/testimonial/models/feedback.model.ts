export class Feedback {
	id: number;
	name: string;
	userimage: string;
	comments: string;
	company: string;
}
