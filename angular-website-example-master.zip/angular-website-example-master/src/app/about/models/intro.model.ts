export class Intro {
	id: number;
	name: string;
	tagline: string;
	title: string;
	description: string;
}
