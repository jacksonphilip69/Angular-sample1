export class Company {
	id: number;
	name: string;
	weblink: string;
	logo: string;
}
