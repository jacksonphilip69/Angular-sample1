export const configuration = {
	header: {
		heading: 'My website',
		headingtext:
			'Namari is a free landing page template you can use for your projects.',
		buttontext: 'do some action',
		buttonlink: 'home',
	},
};
